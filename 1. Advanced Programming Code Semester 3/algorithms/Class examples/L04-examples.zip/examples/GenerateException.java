package examples;

public class GenerateException {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numerator = 10;
        int denominator = 0;
        
        System.out.println( numerator / denominator );
        
        System.out.println("This text will not be shown");
    }
    
}
