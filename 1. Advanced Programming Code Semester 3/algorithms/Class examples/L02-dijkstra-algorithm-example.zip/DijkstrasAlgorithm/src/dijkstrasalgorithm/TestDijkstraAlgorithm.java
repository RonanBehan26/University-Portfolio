package dijkstrasalgorithm;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TestDijkstraAlgorithm {

  private List<Vertex> nodes;
  private List<Edge> edges;

  public static void main(String[] args) {

    TestDijkstraAlgorithm t = new TestDijkstraAlgorithm();
    t.testExcute();

  }

  public void testExcute() {
    nodes = new ArrayList<Vertex>();
    edges = new ArrayList<Edge>();
    for (int i = 0; i < 11; i++) {
      Vertex location = new Vertex("Node_" + i, "Node_" + i);
      nodes.add(location);
    }

    addLane("Edge_0", 0, 1, 4);
    addLane("Edge_1", 0, 7, 8);
    addLane("Edge_2", 1, 2, 12);
    addLane("Edge_3", 2, 3, 19);
    addLane("Edge_4", 2, 8, 14);
    addLane("Edge_5", 7, 6, 9);
    addLane("Edge_6", 6, 5, 11);
    addLane("Edge_7", 5, 4, 21);

    // Lets check from location Loc_1 to Loc_10
    Graph graph = new Graph(nodes, edges);
    DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
    dijkstra.execute(nodes.get(0));
    LinkedList<Vertex> path = dijkstra.getPath(nodes.get(4));

    for (Vertex vertex : path) {
      System.out.println(vertex);
    }
  }

  private void addLane(String laneId, int sourceLocNo, int destLocNo,
          int duration) {
    Edge lane = new Edge(laneId, nodes.get(sourceLocNo), nodes.get(destLocNo), duration);
    edges.add(lane);
  }
}
