class Topic < ApplicationRecord
    has_many :comments
end
