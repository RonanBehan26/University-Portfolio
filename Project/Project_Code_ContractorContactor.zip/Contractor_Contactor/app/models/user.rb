class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
         
         after_create :set_default_role
         belongs_to :role, optional: true
         
         #has_one_attached :profile_picture, dependent: :destroy
         #validates :profile_picture, content_type: [:png, :jpg, :jpeg]
         
         def name
           "#name"
         end
         
         private
         
        #  def set_default_role
        #   self.update[role_id: Role.find_by(code: 'contractor').id]
        #  end
        
        def set_default_role
        self.role ||= Role.find_by_name('contractor')
        end
        
        has_many :topics
        has_many :comments
end
