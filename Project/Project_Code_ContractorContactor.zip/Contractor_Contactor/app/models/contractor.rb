class Contractor < ApplicationRecord
end
