class StaticPagesController < ApplicationController
  
  def home
  end

  def contractorDirectory
  end

  def noticeBoard
  end

  def help
  end
  
  def profile
  end

  
  def adminsection
    
    def upgrade 
	    @user = User.find_by(id: params[:id])
	    @user.update_attribute(:admin, true)
	    redirect_to "/"
	  end
	  
	   def downgrade 
	    @user = User.find_by(id: params[:id])
	    @user.update_attribute(:admin, true)
	    redirect_to "/"
	  end



    
  end
end
