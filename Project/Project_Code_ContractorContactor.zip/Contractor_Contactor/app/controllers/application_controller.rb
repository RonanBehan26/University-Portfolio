class ApplicationController < ActionController::Base
  #protect_from_forgery with: :exception # this was here originally, only this
  
  before_action :configure_permitted_parameters, if: :devise_controller?
  
  protected
  
#   def configure_permitted_parameters# permitting on sign up
#       devise_parameter_sanitizer.permit(:sign_up, keys: [:role_id]) # :name :email :etc :all the things from the table here)
#       added_attrs = [:username]
#   end
# end


  def configure_permitted_parameters# permitting on sign up
      added_attrs = [:username, :email, :password, :password_confirmation, :address1, :remember_me, :phoneNumber, :bio, :profession, :created_at, :updated_at, :date_of_birth] # add in my own
      devise_parameter_sanitizer.permit :sign_up, keys: added_attrs # :name :email :etc :all the things from the table here)
      devise_parameter_sanitizer.permit :account_update, keys: added_attrs
  end
  
end
