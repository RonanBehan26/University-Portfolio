class UserController < ApplicationController
    
    def login
        session[:login] = 1
        session[:cart] = nil
        flash[:notice] = "Admin Login sucessfull!!"
        redirect_to :controller => :static_pages
    end 
    
    def logout
        session[:login] = nil
        session[:cart] = nil
        flash[:notice] = "You have been successfully logged out!!"
        redirect_to :controller => :static_pages
    end    

def profile
    @users = User.all
end


# def edit 
#     # they can only edit themselves
#     @user = current_user
# end

# def update
#     respond_to do |format|
#         if current_user.update(user_params)
#             # they can only update themselves
#             format.html { redirect_to current_user, notice: 'You updated our profile!'}
#         else
#             format.html {render :edit }
#         end
#     end
# end

# private

# def user_params
#     params.require(:user).permit(
#         :bio,
#         :name
#     )
# end
    

end
