require 'test_helper'

class StaticPagesControllerTest < ActionDispatch::IntegrationTest
  test "should get home" do
    get static_pages_home_url
    assert_response :success
  end

  test "should get contractorDirectory" do
    get static_pages_contractorDirectory_url
    assert_response :success
  end

  test "should get noticeBoard" do
    get static_pages_noticeBoard_url
    assert_response :success
  end

  test "should get help" do
    get static_pages_help_url
    assert_response :success
  end

end
