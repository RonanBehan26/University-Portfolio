Rails.application.routes.draw do
  
  get 'comments/new'

  get 'comments/show'

  resources :topics do
    resources :comments, only: [:create, :show, :destroy]
  end
  
  root 'static_pages#home' #this makes this the first page that comes up the home page
    
  devise_for :users #this is due to the rails g devise user
  resources :users, only: [:index, :profile, :edit, :update]
  
  
  resources :contractors
  #DON't delete stuff out of here
  
  get '/admin' => 'static_pages#adminsection'  #the static pages is the controller
  
  get '/home' => 'static_pages#home'
  

  get '/contractorDirectory' => 'static_pages#contractorDirectory'

  get '/noticeBoard' => 'static_pages#noticeBoard'

  get '/help' => 'static_pages#help'
  
  get '/login' => 'static_pages#login'
  
  get '/logout' => 'static_pages#logout'
  
  get '/profile' => 'static_pages#profile'
  
  get '/upgrade/:id' => 'static_pages#upgrade'
  get '/upgrade/:id' => 'static_pages#downgrade'

  
  root :to => 'site#home' # Now we need to set up a route for devise to work from  


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
