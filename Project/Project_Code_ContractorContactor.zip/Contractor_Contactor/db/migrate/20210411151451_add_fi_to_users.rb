class AddFiToUsers < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :address1, :string
    add_column :users, :address2, :string
    add_column :users, :date_of_birth, :date
    add_column :users, :user_reference, :string
  end
end
