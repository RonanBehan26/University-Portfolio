class CreateTopics < ActiveRecord::Migration[5.0]
  def change
    create_table :topics do |t|
      t.string :title
      t.text :comment
      t.text :contact_details

      t.timestamps
    end
  end
end
