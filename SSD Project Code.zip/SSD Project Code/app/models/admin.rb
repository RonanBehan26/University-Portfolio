class Admin < ApplicationRecord
  belongs_to :user
end
