class Offer < ApplicationRecord
end
