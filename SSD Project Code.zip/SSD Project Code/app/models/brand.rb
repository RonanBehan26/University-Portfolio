class Brand < ApplicationRecord
end
