class ContactController < ApplicationController

end
