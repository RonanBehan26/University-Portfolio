
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ThreadedServer {

  public static void main(String[] args) {
    int port = 8080;

    ServerSocket serverSocket = null;
    Socket connSocket;

    try {
      System.out.println("Waiting for a connection on port " + port + ".");
      serverSocket = new ServerSocket(port);
      while (true) {
        try {
          connSocket = serverSocket.accept();
          Thread areaThread = new Thread(new AreaThread(connSocket));
          areaThread.start();
        } catch (IOException e) {
          System.out.println(e.getMessage());
        }
      }
    } catch (IOException e) {
      System.out.println(e.getMessage());
    } finally {
      try {
        serverSocket.close();
      } catch (IOException e) {
        System.out.println(e.getMessage());
      }
    }
  }
}

class AreaThread implements Runnable {

  Socket connSocket;

  public AreaThread(Socket connSocket) {
    this.connSocket = connSocket;
  }

  public void run() {
    BufferedReader clientInput;
    DataOutputStream clientOutput;

    String radius;
    Double circleArea;

    try {
      clientInput = new BufferedReader(
              new InputStreamReader(connSocket.getInputStream()));
      clientOutput = new DataOutputStream(
              connSocket.getOutputStream());
      System.out.println("Connection established.");
      radius = clientInput.readLine();
      System.out.println(radius);

      circleArea = Math.PI * Math.pow(Double.parseDouble(radius), 2);

      clientOutput.writeBytes(circleArea.toString());
      System.out.println("Circle area sent: " + circleArea.toString());

      clientOutput.close();
      clientInput.close();
      this.connSocket.close();
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }
}
