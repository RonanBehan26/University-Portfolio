
public class Task3 implements Runnable {

  private String word;
  private int num;

  public Task3(String whatToSay, int numTimes) {
    this.word = whatToSay;
    this.num = numTimes;
  }

  @Override
  public void run() {
    for (int i = 0; i < this.num; i++) {
      System.out.println(this.word + " ");
    }
  }

  public static void main(String args[]) {
    Thread first = new Thread(new Task3("First", 2));
    Thread second = new Thread(new Task3("Second", 2));

    first.setPriority(1);
    second.setPriority(2);

    second.start();
    first.start();
  }
}
