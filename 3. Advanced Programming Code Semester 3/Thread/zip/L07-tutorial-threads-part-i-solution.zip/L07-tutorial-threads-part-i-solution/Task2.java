
public class Task2 {

  public static void main(String args[]) {
    for (int i = 0; i < 10; i++) {
      Thread x = new Thread();
      x.setName(Long.toBinaryString(i));
      System.out.println(x.getName());
    }
  }
}
