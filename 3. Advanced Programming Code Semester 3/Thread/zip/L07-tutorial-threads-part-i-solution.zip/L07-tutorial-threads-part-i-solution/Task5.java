
public class Task5 implements Runnable {

  private int delay;

  public Task5(int delayTime) {
    this.delay = delayTime;
  }

  public void run() {
    try {
      Thread.sleep(this.delay);
    } catch (InterruptedException e) {
      return;
    }
  }

  public static void main(String args[]) {
    for (int i = 0; i < 1000; i++) {
      Runnable p = new Task5(0);
      new Thread(p).start();
      System.out.println(Thread.activeCount());
    }
  }
}
