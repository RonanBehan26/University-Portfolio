
public class Task1 {

  public static void main(String args[]) {
    for (int i = 0; i < 10; i++) {
      Thread x = new Thread();
      System.out.println(x.getId());
    }
  }
}
