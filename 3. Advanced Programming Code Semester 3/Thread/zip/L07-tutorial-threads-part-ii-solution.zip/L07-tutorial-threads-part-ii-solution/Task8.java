
public class Task8 {

  public static void main(String[] args) {

    CubbyHole c = new CubbyHole();

    Producer p1 = new Producer(c, 1);
    Consumer c1 = new Consumer(c, 1);

    p1.start();
    c1.start();
  }
}

class CubbyHole {

  private int contents;
  private boolean available = false;

  public synchronized int get(int who) {
    while (this.available == false) {
      try {
        wait();
      } catch (InterruptedException e) {
      }
    }
    this.available = false;
    System.out.println("Consumer " + who + " got: " + this.contents);
    notifyAll();
    return this.contents;
  }

  public synchronized void put(int who, int value) {
    while (this.available == true) {
      try {
        wait();
      } catch (InterruptedException e) {
      }
    }
    this.contents = value;
    this.available = true;
    System.out.format("Producer " + who + " put: " + this.contents);
    notifyAll();
  }
}

class Producer extends Thread {

  private CubbyHole cubbyhole;
  private int number;

  public Producer(CubbyHole c, int number) {
    this.cubbyhole = c;
    this.number = number;
  }

  public void run() {
    for (int i = 0; i < 10; i++) {
      this.cubbyhole.put(this.number, i);
      try {
        sleep((int) (Math.random() * 100));
      } catch (InterruptedException e) {
      }
    }
  }
}

class Consumer extends Thread {

  private CubbyHole cubbyhole;
  private int number;

  public Consumer(CubbyHole c, int number) {
    this.cubbyhole = c;
    this.number = number;
  }

  public void run() {
    for (int i = 0; i < 10; i++) {
      this.cubbyhole.get(this.number);
    }
  }
}
