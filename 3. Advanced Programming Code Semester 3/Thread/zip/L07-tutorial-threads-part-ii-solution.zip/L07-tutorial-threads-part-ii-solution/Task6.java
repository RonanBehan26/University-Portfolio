
class Task6 implements Runnable {

  Thread t;

  Task6() {
    this.t = new Thread(this);
    this.t.start();
  }

  public void run() {
    System.out.println("Inside run method, priority " + this.t.getPriority());
  }

  public static void main(String[] args) {
    Thread.currentThread().setPriority(Thread.MAX_PRIORITY);

    System.out.println("main thread priority : "
            + Thread.currentThread().getPriority());

    new Thread(new Task6());
  }
}
