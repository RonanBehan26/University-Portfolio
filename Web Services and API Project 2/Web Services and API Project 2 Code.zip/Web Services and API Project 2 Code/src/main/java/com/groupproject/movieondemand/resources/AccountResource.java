package com.groupproject.movieondemand.resources;


import com.groupproject.movieondemand.models.Account;
import com.groupproject.movieondemand.models.DealingWithMovies;
import com.groupproject.movieondemand.services.AccountService;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("/customer/{custid}/account")
public class AccountResource {
    
    private AccountService accountService = new AccountService();
    
    /*
       Gets a list of accounts for a customer
    */
    
    @GET
    @Produces (MediaType.APPLICATION_JSON)
    public ArrayList<Account> getAccountList(@PathParam("custid") int custid) {
        ArrayList<Account> accountlist = accountService.getAccountList(custid);
        if (accountlist != null) {
            // if the customer was found return the list of accounts
            return accountlist;
        } else {
            // otherwise return a 404 status code
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }
    /* 
        Adds an account to a customer, it works here to add a family member account
    */
    @POST
    @Produces (MediaType.APPLICATION_JSON)
    @Consumes (MediaType.APPLICATION_JSON)
    public Account addAccount(@PathParam("custid") int custid, Account account) {
        Account newaccount = accountService.addAccount(custid,account);
        if (newaccount != null) {
            // if the customer was found and account was created, return the account
            return newaccount;
        } else {
            // otherwise return a 404 status code
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }
    
//account - any update
    //add, delete
    @PUT
    @Produces (MediaType.APPLICATION_JSON)
    @Consumes (MediaType.APPLICATION_JSON)
    @Path("/{accountid}")
    public Account movieOnDemand(@PathParam("custid") int custid, @PathParam("accountid") int accountid, 
                                  DealingWithMovies demand) {
        Account updatedAccount = accountService.movieOnDemand(custid, accountid, demand);
        
        if (updatedAccount != null) {
           // if the account was found, return the account
           return updatedAccount;
        } else {
           // otherwise return a 404 status code
           throw new WebApplicationException(Response.Status.NOT_FOUND); 
        }
        
        
    }
}

/* //Here are some other methods that we worked on and thought were good additions, in the end we left them out for better functionality
    ArrayList<Account> famMemberlist = new ArrayList<Account>();//this is adding a family member
    ArrayList<String> Movielist = new ArrayList<String>();
    ArrayList<Customer> Customer = new ArrayList<Customer>();
    ArrayList<String> famMemberMovielist = new ArrayList<String>();
    
         @POST // add fam member
    @Produces (MediaType.APPLICATION_JSON)
    @Consumes (MediaType.APPLICATION_JSON)
    public Account addfamMember (@PathParam("addfamUser") String famusername, String fampassword, int famID) {
        Account a = new Account(famusername, fampassword, famID);
        famMemberlist.add(a); //add a famMember to the list
        return a;
        }
    
        @POST // add a movie
        @Produces (MediaType.APPLICATION_JSON)
        @Consumes (MediaType.APPLICATION_JSON)
    public Movies setMovieList(@PathParam("setMovie") int movieID, String movieName, String movieFlag, String movieRecommended, String summary, String releaseDate) {
        Movies m = new Movies(movieID, movieName, movieFlag, movieRecommended, summary, releaseDate);
        Movielist.add(m); //add a famMember to the list
        return m;
    }
    
    
       @GET // get the list of movies
    @Produces (MediaType.APPLICATION_JSON)
    public ArrayList<String> getMovielist(@PathParam("MovieIDList") int movieID, String movieName, String movieFlag, String movieRecommended, String summary, String releaseDate) {
        ArrayList<String> Movielist = getMovielist(movieID, movieName, movieFlag, movieRecommended, summary, releaseDate);
        return this.Movielist;
    }
   
    
    @DELETE // delete a movie, up for debate
    @Path("/{deleteMovieID}")
    @Produces(MediaType.APPLICATION_XML)
    public Response deleteMovie(@PathParam("deleteMovieID") int movieID, String movieName, String movieFlag, String movieRecommended, String summary, String releaseDate){
        //if(){ //if movieID is userinput delete
            
        Movielist.remove(movieID); //can change later
        return Response.status(200).entity("Movie Removed from your list").build(); 
        //}
    }
    
        @POST // add a customer
        @Produces (MediaType.APPLICATION_JSON)
        @Consumes (MediaType.APPLICATION_JSON)
    public MovieOnDemand setCustomer(@PathParam("AddCustomer") String username, String password) {
        MovieOnDemand  g = new MovieOnDemand(username, password);
        Customer.add(g); //add a famMember to the list
        return g;
       
        }
*/
