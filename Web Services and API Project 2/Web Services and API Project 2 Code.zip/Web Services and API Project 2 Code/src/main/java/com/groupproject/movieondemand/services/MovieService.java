package com.groupproject.movieondemand.services;

import com.groupproject.movieondemand.database.DB;
import com.groupproject.movieondemand.database.Database;
import com.groupproject.movieondemand.models.Customer;
import com.groupproject.movieondemand.models.Movie;
import java.util.ArrayList;

public class MovieService {
    //this is all for retrieving movies
    Database db = DB.getInstance();

    public ArrayList<Movie> getMovieDB() { // this produces the list of movies on the account
        System.out.println("Getting Movie list");
        return db.getMovieDB();
    }
    
    public Movie getMovie(int movieID) {
        Movie foundMovie = null;
        
        for (Movie move: db.getMovieDB()) {
            if (move.getMovieID() == movieID) {
                foundMovie = move;
            }
        }
        return foundMovie;
    }
    //this is all for adding movies
    public Movie addMovie(Movie move) {
        move.setMovieID(DB.getInstance().nextMovieID());
        DB.getInstance().movieDB.add(move);
        return move;
    }
    //this is all for deleting movies
      public Movie removeMovie(Movie move) {
        move.setMovieID(DB.getInstance().nextMovieID());
        DB.getInstance().movieDB.remove(move);
        return move;
    }
   
    
}
  
