package com.groupproject.movieondemand.models;

public enum AccountType {
    Adult, //Over 21
    Teenager, //from 13 to 21 inclusive
    Kids// 2 to 12 inclusive
    
}