package com.groupproject.movieondemand.resources;

import com.groupproject.movieondemand.models.FamilyMember;
import com.groupproject.movieondemand.models.Movie;
import com.groupproject.movieondemand.services.MovieService;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


// this is for the list of movies
@Path("/movie")
public class MovieResource {
    
    MovieService movieService = new MovieService();
   private ArrayList<FamilyMember> famMemberMovielist;
    
       
      @GET
   @Produces(MediaType.APPLICATION_JSON)
   public ArrayList<Movie> getMovieDB() {
      return movieService.getMovieDB();
   }

   /**     //transfer a movie from one list to another, up for debate
    @PUT
    @Produces (MediaType.APPLICATION_JSON)
    @Consumes (MediaType.APPLICATION_JSON) //transfer a movie from one list to another
    public ArrayList<String> getMovielist(@PathParam("Transfer_Movie") long movieID, String movieName, 
            String releaseDate, String movieCategory, String movieFlag, String recommended, String summary) {
        Movie  z = new Movie(movieID, movieName, releaseDate, movieCategory, movieFlag, recommended, summary);
        famMemberMovielist.add(z);
    public ArrayList<FamilyMember> setFamMemberMovielist(@PathParam("famMovieID") int fammovieID, 
            String fammovieName, String fammovieFlag, String fammovieRecommended, String famsummary, 
            String famreleaseDate)  { 
        //Account f = new Account(movieID, movieName, movieFlag, movieRecommended, summary, releaseDate);
        
        //ArrayList<String> famMemberMovielist = new ArrayList(Movielist); // this is to copy all elements
        //set famMemberMovielist
      return famMemberMovielist;
    }
   */
}
