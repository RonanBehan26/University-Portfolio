package com.groupproject.movieondemand.services;

import com.groupproject.movieondemand.database.DB;
import com.groupproject.movieondemand.database.Database;
import com.groupproject.movieondemand.models.Account;
import com.groupproject.movieondemand.models.AccountType;
import com.groupproject.movieondemand.models.Customer;
import com.groupproject.movieondemand.models.DealingWithMovies;
import java.util.ArrayList;

public class AccountService {

   Database db = DB.getInstance();
   private String Activated;

   public ArrayList<Account> getAccountList(int customerID) {
      Customer foundCustomer = null;
      ArrayList<Account> accountlist = null;

      // search through the customer list for the customer with customerID
      for (Customer cust : db.getCustomerDB()) {
         if (cust.getId() == customerID) {
            foundCustomer = cust;
         }
      }
      // if the customer was found, set the accountlist to be returned
      if (foundCustomer != null) {
         accountlist = foundCustomer.getAccountlist();
      }
      return accountlist;
   }

   public Account addAccount(int customerID, Account account) {
      Customer foundCustomer = null;

      // search through the customer list for the customer with customerID
      for (Customer cust : db.getCustomerDB()) {
         if (cust.getId() == customerID) {
            foundCustomer = cust;
         }
      }
      if (foundCustomer != null) {
         // create a new account, setting a new ID and default balance
         account.setAccountID(db.nextAccountID());
         if (foundCustomer.getAge() <= 5) {
            account.setAccountType(AccountType.Kids);
         } else if (foundCustomer.getAge() >= 12 && foundCustomer.getAge() <= 21) {
            account.setAccountType(AccountType.Teenager);
         } else {
            account.setAccountType(AccountType.Adult);
         }

         // add the newly created account to the customer's account list
         foundCustomer.getAccountlist().add(account);
      }
      return account;
   }

   public Account movieOnDemand(int customerID, int accountID, DealingWithMovies demand) {
      Customer foundCustomer = null;
      Account foundAccount = null;
      int accountIndex = -1;
      // search through the customer list for the customer with customerID
      for (Customer cust : db.getCustomerDB()) {
         if (cust.getId() == customerID) {
            foundCustomer = cust;
         }
      }
      // if the customer was found and has one or more accounts
      if (foundCustomer != null && foundCustomer.getAccountlist().size() > 0) {
         // search for the account id in the list of accounts
         for (int i = 0; i < foundCustomer.getAccountlist().size(); i++) {
            if (foundCustomer.getAccountlist().get(i).getAccountID() == accountID) {
               accountIndex = i;
            }
         }
      }
      // if customer exist and the account id is valid for the customer
      if (foundCustomer != null && accountIndex != -1) {
         foundAccount = foundCustomer.getAccountlist().get(accountIndex);

      }
      return foundAccount;
   }
}
