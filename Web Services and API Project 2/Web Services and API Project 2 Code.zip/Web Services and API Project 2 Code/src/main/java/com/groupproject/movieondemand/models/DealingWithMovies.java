package com.groupproject.movieondemand.models;

public enum DealingWithMovies {
    AddMovie,
    RemoveMovie,
    TransferMovie;
      
}