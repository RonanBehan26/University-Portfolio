package com.groupproject.movieondemand.models;

import java.util.ArrayList;

public class Customer {
    
    private int id;
    private String fnames;
    private String surname;
    private int age;
    private ArrayList<Account> accountlist;

    public Customer() {
    }

    public Customer(int ID, String forenames, String surname, int age) {
        this.id = ID;
        this.fnames = forenames;
        this.surname = surname;
        this.age = age;
        this.accountlist = new ArrayList<>();
    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFnames() {
        return fnames;
    }

    public void setFnames(String forenames) {
        this.fnames = forenames;
    }

    public String getSurname() {
        return surname;
    }

    public ArrayList<Account> getAccountlist() {
        return accountlist;
    }
     

    public void setSurname(String surname) {
        this.surname = surname;
    }

   public int getAge() {
      return age;
   }

   public void setAge(int age) {
      this.age = age;
   }
    
    
}//end class Customer
