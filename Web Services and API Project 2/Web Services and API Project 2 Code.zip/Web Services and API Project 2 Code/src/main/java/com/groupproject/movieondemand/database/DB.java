package com.groupproject.movieondemand.database;

public class DB {

    private final static Database instance = new Database();

    public static Database getInstance() {
        return instance;
    }
}
