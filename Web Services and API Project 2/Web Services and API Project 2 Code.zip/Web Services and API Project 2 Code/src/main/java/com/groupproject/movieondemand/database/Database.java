package com.groupproject.movieondemand.database;


import com.groupproject.movieondemand.models.Customer;
import com.groupproject.movieondemand.models.FamilyMember;
import com.groupproject.movieondemand.models.Movie;
import java.util.ArrayList;



public class Database {

    public ArrayList<Customer> customerDB;
    public ArrayList<Movie> movieDB;
    public ArrayList<FamilyMember> fmDB;    
    public boolean initialised = false;
    private int maxCustomerID = 0;
    private int maxAccountID = 0;
    private int maxMovieID = 0;
    private int maxfamMemberID = 0;


    public Database() {

        if (!initialised) {
              customerDB = new ArrayList<>();
              customerDB.add(new Customer(nextCustomerID(),"Maria","O Fatharta", 5));
              customerDB.add(new Customer(nextCustomerID(),"Liam","O Fatharta", 14));
              customerDB.add(new Customer(nextCustomerID(),"Ronan", "Behan", 32));
              customerDB.add(new Customer(nextCustomerID(),"Geneci","Cruz", 40));
              
              movieDB = new ArrayList<>();
              movieDB.add(new Movie(nextMovieID(),"The return of us", "27/12/2019","Kids", "Seen", "8/10", "Coming of age"));
              movieDB.add(new Movie(nextMovieID(),"Pinguins", "27/10/2000","Kids", "Seen", "9/10", "Coming of age"));
              movieDB.add(new Movie(nextMovieID(),"Try Java Hard", "27/09/2019","Adult", "Seen", "7/10", "Coming of age"));
              movieDB.add(new Movie(nextMovieID(),"Try Again", "10/12/2020","Adult", "Seen", "6/10", "Coming of age"));
              movieDB.add(new Movie(nextMovieID(),"Never Mind", "20/01/2017","Teenager", "Seen", "8/10", "Coming of age"));
              movieDB.add(new Movie(nextMovieID(),"Finally Here", "27/12/2019","Teenager", "Seen", "9/10", "Coming of age"));
              
              
              //here we are adding 
              fmDB = new ArrayList<>();
              fmDB.add(new FamilyMember(nextFamilyMemberID(),"Lotr", "Seen","6/10", "Fantasy", "27/12/2004"));
              
        }
        initialised = true;

    }

    public ArrayList<Customer> getCustomerDB() {
        return customerDB;
    }
    
    public int nextCustomerID() {
        
        maxCustomerID = maxCustomerID + 1;
        return maxCustomerID;
    }
    
    public int nextAccountID() {
        maxAccountID = maxAccountID + 1;
        return maxAccountID;
    }
    
    
     public ArrayList<Movie> getMovieDB() {
        return movieDB;
    }
     
    
    public int nextMovieID() {
        
        maxMovieID = maxMovieID + 1;
        return maxMovieID;
    }
    
        public ArrayList<FamilyMember> getFamMemberDB() { // family member has been created
        return fmDB;
    }
    
        public int nextFamilyMemberID() { //this is creating the family member ID
        
        maxfamMemberID = maxfamMemberID + 1;
        return maxfamMemberID;
    }
        

}
