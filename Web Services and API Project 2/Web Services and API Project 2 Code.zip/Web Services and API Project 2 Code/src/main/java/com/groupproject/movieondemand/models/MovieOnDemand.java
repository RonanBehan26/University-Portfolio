package com.groupproject.movieondemand.models;

import java.util.ArrayList;

public final class MovieOnDemand {
    private static ArrayList<Customer> customerlist;
    private static ArrayList<FamilyMember> famMemberList;

    private MovieOnDemand() {
        this.customerlist = new ArrayList<>();
        this.famMemberList = new ArrayList<>();
        
    }

    public static ArrayList<Customer> getCustomerlist() {
        return customerlist;
    }
    
    public static ArrayList<FamilyMember> getFamilyMemberList() {
        return famMemberList;
    }    
     
}
