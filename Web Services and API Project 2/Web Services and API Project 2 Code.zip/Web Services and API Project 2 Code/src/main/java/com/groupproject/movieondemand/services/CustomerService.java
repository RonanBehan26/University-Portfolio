package com.groupproject.movieondemand.services;


import com.groupproject.movieondemand.database.DB;
import com.groupproject.movieondemand.database.Database;
import com.groupproject.movieondemand.models.Customer;
import java.util.ArrayList;

public class CustomerService {
   
    Database db = DB.getInstance();

    public ArrayList<Customer> getCustomerList() {
        System.out.println("Getting customer list");
        return db.getCustomerDB();
    }
    
    public Customer getCustomer(int customerID) {
        Customer foundCustomer = null;
        
        for (Customer cust: db.getCustomerDB()) {
            if (cust.getId() == customerID) {
                foundCustomer = cust;
            }
        }
        return foundCustomer;
    }
    
    public Customer addCustomer(Customer cust) {
        cust.setId(DB.getInstance().nextCustomerID());
        DB.getInstance().customerDB.add(cust);
        return cust;
    }
   
    
}
