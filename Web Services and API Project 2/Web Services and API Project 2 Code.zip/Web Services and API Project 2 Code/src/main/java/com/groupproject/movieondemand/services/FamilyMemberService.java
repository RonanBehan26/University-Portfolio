package com.groupproject.movieondemand.services;

import com.groupproject.movieondemand.database.DB;
import com.groupproject.movieondemand.database.Database;
import com.groupproject.movieondemand.models.FamilyMember;
import java.util.ArrayList;

public class FamilyMemberService {

   Database db = DB.getInstance();
//this is for getting the family member list

   public ArrayList<FamilyMember> getFamMemberDB() {
      System.out.println("Getting family member movie list list");
      return db.getFamMemberDB();
   }

   public FamilyMember getFamMember(int fammovieID) {
      FamilyMember foundFam = null;

      for (FamilyMember fam : db.getFamMemberDB()) {
         if (fam.getFammovieID() == fammovieID) {
            foundFam = fam;
         }
      }
      return foundFam;
   }

   public FamilyMember addFamMember(FamilyMember fam) {
      fam.setFammovieID(DB.getInstance().nextFamilyMemberID());
      DB.getInstance().fmDB.add(fam);
      return fam;
   }

}
