package com.groupproject.movieondemand.models;

import java.util.ArrayList;

public class Movie {

   private long movieID;
   private String movieName;
   private String releaseDate;
   private String movieCategory;
   private String movieFlag;
   private String recommended;
   private String summary;
   
   private static ArrayList<Movie> movieList;

   public Movie() {

   }

    public Movie(long movieID, String movieName, String releaseDate, String movieCategory, String movieFlag, String recommended, String summary) {
        this.movieID = movieID;
        this.movieName = movieName;
        this.releaseDate = releaseDate;
        this.movieCategory = movieCategory;
        this.movieFlag = movieFlag;
        this.recommended = recommended;
        this.summary = summary;
    }
   
   
   
    public long getMovieID() {
        return movieID;
    }

    public void setMovieID(long movieID) {
        this.movieID = movieID;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getMovieCategory() {
        return movieCategory;
    }

    public void setMovieCategory(String movieCategory) {
        this.movieCategory = movieCategory;
    }

    public String getMovieFlag() {
        return movieFlag;
    }

    public void setMovieFlag(String movieFlag) {
        this.movieFlag = movieFlag;
    }

    public String getRecommended() {
        return recommended;
    }

    public void setRecommended(String recommended) {
        this.recommended = recommended;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public static ArrayList<Movie> getMovieList() {
        return movieList;
    }

    public static void setMovieList(ArrayList<Movie> movieList) {
        Movie.movieList = movieList;
    }

  
}
