package com.groupproject.movieondemand.resources;



import com.groupproject.movieondemand.models.Customer;
import com.groupproject.movieondemand.models.Movie;
import com.groupproject.movieondemand.services.CustomerService;
import com.groupproject.movieondemand.services.MovieService;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



@Path("/customer")
public class CustomerResource {

   CustomerService customerService = new CustomerService();

   /* 
        Returns a list of all customers
        We hard coded a list of customers
    */
   @GET
   @Produces(MediaType.APPLICATION_JSON)
   public ArrayList<Customer> getCustomerList() {
      return customerService.getCustomerList();
   }
   

   /* 
        Returns a details of a single customer ID
    */
   @GET
   @Path("/{custid}")
   public Customer getCustomer(@PathParam("custid") int custid) {
      Customer customer = customerService.getCustomer(custid);
      if (customer != null) {
         return customer;
      } else {
         throw new WebApplicationException(Response.Status.NOT_FOUND);
      }
   }

   @POST
   @Produces(MediaType.APPLICATION_JSON)
   @Consumes(MediaType.APPLICATION_JSON)
   public Customer addCustomer(Customer cust) {
      return customerService.addCustomer(cust);
   }

}// end class CustomerResource
