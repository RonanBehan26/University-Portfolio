package com.groupproject.movieondemand.models;

import com.groupproject.movieondemand.database.Database;
import java.util.ArrayList;

public class Account {
    
    private Database db = new Database();

    private long accountID;
    private AccountType accountType;
    private String accountStatus;
    private long movieID;
    

    public Account() {
        
    }

    public Account(AccountType accountType) {
        this.accountID = db.nextAccountID();
        this.accountType = accountType;
        this.accountStatus = "activated";
    }

   public Account(long movieID) {
      this.movieID = movieID;
   }   

    public long getAccountID() {
        return this.accountID;
    }

    public AccountType getAccountType() {
        return this.accountType;
    }

    public String getStatus() {
        return this.accountStatus;
    }

    public void setAccountID(long accountID) {
        this.accountID = accountID;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

   public long getMovieID() {
      return movieID;
   }

   public void setMovieID(long movieID) {
      this.movieID = movieID;
   }
    
    

}//end class Database
