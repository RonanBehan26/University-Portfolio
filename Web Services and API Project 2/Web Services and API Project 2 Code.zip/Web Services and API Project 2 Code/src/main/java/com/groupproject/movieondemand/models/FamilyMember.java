package com.groupproject.movieondemand.models;

import java.util.ArrayList;

/**
 *
 * @author Ronan
 */
public class FamilyMember {

    private int fammovieID;
    private String fammovieName;
    private String fammovieFlag; 
    private String fammovieRecommended; 
    private String famsummary; 
    private String famreleaseDate;
 
    private ArrayList<String> famMemberMovielist; //this is adding a family member movie

    public FamilyMember() {
    }

    public FamilyMember(String fammovieName, String fammovieFlag, String fammovieRecommended, String famsummary, String famreleaseDate) {
        this.fammovieID = fammovieID;
        this.fammovieName = fammovieName;
        this.fammovieFlag = fammovieFlag;
        this.fammovieRecommended = fammovieRecommended;
        this.famsummary = famsummary;
        this.famreleaseDate = famreleaseDate;
        this.famMemberMovielist = famMemberMovielist;
    }

   public FamilyMember(int nextFamilyMemberID, String lotr, String seen, String string, String fantasy, String string0) {
      throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   }
    
    
    public int getFammovieID() {
        return fammovieID;
    }

    public void setFammovieID(int fammovieID) {
        this.fammovieID = fammovieID;
    }

    public String getFammovieName() {
        return fammovieName;
    }

    public void setFammovieName(String fammovieName) {
        this.fammovieName = fammovieName;
    }

    public String getFammovieFlag() {
        return fammovieFlag;
    }

    public void setFammovieFlag(String fammovieFlag) {
        this.fammovieFlag = fammovieFlag;
    }

    public String getFammovieRecommended() {
        return fammovieRecommended;
    }

    public void setFammovieRecommended(String fammovieRecommended) {
        this.fammovieRecommended = fammovieRecommended;
    }

    public String getFamsummary() {
        return famsummary;
    }

    public void setFamsummary(String famsummary) {
        this.famsummary = famsummary;
    }

    public String getFamreleaseDate() {
        return famreleaseDate;
    }

    public void setFamreleaseDate(String famreleaseDate) {
        this.famreleaseDate = famreleaseDate;
    }

    public ArrayList<String> getFamMemberMovielist() {
        return famMemberMovielist;
    }

    //dealing with the family member movie account
    public void setFamMemberMovielist(ArrayList<String> famMemberMovielist) {
        this.famMemberMovielist = famMemberMovielist;
    
}
}
